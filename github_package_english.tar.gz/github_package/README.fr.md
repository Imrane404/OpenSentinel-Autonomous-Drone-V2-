# 🚁 Contrôleur de Drone Autonome - Suivi IA Webots

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Webots](https://img.shields.io/badge/Webots-R2023b+-orange.svg)](https://cyberbotics.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![YOLO](https://img.shields.io/badge/YOLO-v11-red.svg)](https://github.com/ultralytics/ultralytics)

> 🌍 **[English version](README.md)** | 🇫🇷 Version française

Un contrôleur de drone autonome avancé avec **suivi visuel en temps réel** basé sur l'IA, développé pour le simulateur Webots et le drone Mavic 2 Pro.

![Demo](docs/images/demo.gif)

## ✨ Fonctionnalités

### 🎯 Suivi visuel intelligent
- **Détection par IA** : YOLOv11 pour détecter n'importe quel objet (personne, voiture, animal, etc.)
- **Tracking hybride** : Fusion YOLO + KCF pour un suivi fluide et robuste
- **Centrage automatique** : Le drone pivote pour garder l'objet au centre de la caméra
- **Contrôle de distance** : Maintient automatiquement une distance optimale (30-40% de l'écran)
- **Suivi en temps réel** : Réactivité de 95% (alpha=0.95) avec re-détection toutes les 0.3s

### 🎮 Contrôle avancé
- **Interface web complète** : Dashboard moderne avec flux vidéo en direct
- **Modes de vol multiples** :
  - 🔍 **SEARCH** : Rotation automatique pour chercher l'objet
  - 🎯 **FOLLOW** : Suivi visuel actif avec centrage
  - 🔄 **ORBIT** : Orbite autour de la cible
  - 🏠 **RTH** : Retour automatique au point de départ
  - ✋ **MANUAL** : Contrôle clavier complet
- **Contrôles clavier** : ZQSD + touches pour altitude/rotation
- **Ajustements en direct** : Altitude et vitesse de rotation réglables

### 📹 Enregistrement & Logs
- **Capture photo/vidéo** : Enregistrement HD avec annotations
- **Logs JSON détaillés** : Tous les événements avec timestamps
- **Filtres personnalisables** : Active/désactive les types de logs en temps réel
- **Téléchargement logs** : Export JSON pour analyse

### 🛡️ Sécurité & Stabilisation
- **Geofencing** : Zone de sécurité configurable
- **Détection bord** : Arrêt automatique si objet près du bord de l'image
- **Contrôle PID optimisé** : Stabilisation roll/pitch/yaw
- **Ajustement altitude dynamique** : Altitude adaptée selon distance objet

## 🚀 Installation

### Prérequis
- **Webots R2023b+** : [Télécharger](https://cyberbotics.com/#download)
- **Python 3.8+**
- **4GB RAM minimum** (8GB recommandés pour YOLO)

### Installation rapide

```bash
# 1. Cloner le repository
git clone https://github.com/votre-username/autonomous-drone-webots.git
cd autonomous-drone-webots

# 2. Installer les dépendances
pip install -r requirements.txt

# 3. Ouvrir le monde Webots
# File > Open World > mavic_2_pro.wbt

# 4. Lancer la simulation
# Cliquez sur ▶️ Play dans Webots
# Ouvrez http://localhost:5010
```

Pour un guide complet, consultez le [Guide de démarrage rapide](QUICKSTART.md).

## 🎮 Utilisation

### Démarrage rapide (5 minutes)

1. **Décollage** : Cliquez sur `🛫 Takeoff`
2. **Recherche** : Entrez "person" (ou "car", "dog") et cliquez `🔍 Start Search`
3. **Suivi automatique** : Le drone détecte et suit l'objet automatiquement
4. **Atterrissage** : Cliquez sur `🛬 Land`

### Contrôles clavier (Mode Manual)
```
Z : Avancer        Q : Rotation gauche
S : Reculer        D : Rotation droite
E : Monter         A : Descendre
```

## ⚙️ Configuration

Les paramètres principaux se trouvent dans `drone_controller.py` :

```python
# Suivi visuel (lignes 1204-1205)
KP_YAW = 1.2           # Vitesse de rotation
YAW_DEADZONE = 0.05    # Tolérance centrage (5%)

# Distance optimale (lignes 1237-1240)
ZONE_OPTIMAL_MIN = 30.0  # 30-40% de l'écran
ZONE_OPTIMAL_MAX = 40.0
```

## 📁 Structure du projet

```
autonomous-drone-webots/
├── controllers/
│   └── drone_controller/
│       └── drone_controller.py      # Contrôleur principal
├── worlds/
│   └── mavic_2_pro.wbt             # Monde Webots
├── docs/
│   └── ARCHITECTURE.md              # Documentation technique
├── README.md                        # Documentation (EN)
├── README.fr.md                     # Documentation (FR)
├── QUICKSTART.md                    # Guide rapide
├── requirements.txt                 # Dépendances
└── LICENSE                          # Licence MIT
```

## 🏗️ Architecture

Le système utilise une architecture hybride innovante :

```
Caméra → YOLO (détection) + KCF (tracking) 
       → EMA Filter (lissage)
       → PID Control (yaw/pitch/roll)
       → Moteurs
```

Pour plus de détails, consultez [ARCHITECTURE.md](docs/ARCHITECTURE.md).

## 📊 Performances

| Métrique | Valeur |
|----------|--------|
| FPS détection | 15-30 FPS |
| Latence suivi | ~33ms |
| Précision centrage | ±5% |
| Temps approche (15m) | 5-8 secondes |
| Zone optimale | 30-40% écran |

## 🔧 Dépannage

### Le drone ne décolle pas
- Vérifiez que Webots est en mode "Run" (pas Pause)

### YOLO ne détecte rien
- Objets supportés : [Liste COCO](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/cfg/datasets/coco.yaml)
- Distance max : ~15m

### Port 5010 déjà utilisé
- Modifier `HTTP_PORT` ligne 644
- Relancer la simulation

## 🛣️ Roadmap

- [x] Suivi visuel avec centrage automatique
- [x] Interface web complète
- [x] Modes de vol multiples
- [ ] Multi-objets tracking
- [ ] Path planning avec obstacles
- [ ] Intégration ROS2
- [ ] Support drone réel (PX4/ArduPilot)

## 🤝 Contribution

Les contributions sont les bienvenues ! Voir [CONTRIBUTING.md](CONTRIBUTING.md) pour les détails.

## 📝 License

Ce projet est sous licence MIT - voir [LICENSE](LICENSE).

## 👏 Remerciements

- **Webots** : Simulateur robotique open-source
- **Ultralytics YOLO** : Modèle de détection d'objets
- **OpenCV** : Bibliothèque vision par ordinateur
- **Flask** : Framework web Python

## 📧 Contact

- Ouvrir une [Issue](https://github.com/votre-username/autonomous-drone-webots/issues)
- Pull Requests bienvenues !

---

⭐ Si ce projet vous a été utile, n'oubliez pas de lui donner une étoile !

🌍 **[English version available](README.md)**
